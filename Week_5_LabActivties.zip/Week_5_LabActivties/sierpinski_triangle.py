from tkinter import * # Import tkinter
import math
class KochSnowflake:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Koch snowflake") # Set a title
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window,
            width = self.width, height = self.height)
        self.canvas.pack()
        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()
        Label(frame1,
            text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order,
            justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display",
            command = self.display).pack(side = LEFT)
        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")
        cx = self.width / 2
        cy = self.height / 2
        size = 160
        p1 = [cx, cy - size]
        p2 = [cx + size * math.sin(2 * math.pi / 3), cy - size * math.cos(2 * math.pi / 3)]
        p3 = [cx + size * math.sin(4 * math.pi / 3), cy - size * math.cos(4 * math.pi / 3)]
        self.displaySegments(int(self.order.get()), p1, p2)
        self.displaySegments(int(self.order.get()), p2, p3)
        self.displaySegments(int(self.order.get()), p3, p1)

    def displaySegments(self, order, p1, p2):
        if order == 0: # Base condition
            # Draw a line to connect two points
            self.drawLine(p1, p2)
        else:
            # Get the third and two-third points along the edge
            p13 = self.thirdpoint(p1, p2, 1)
            p23 = self.thirdpoint(p1, p2, 2)
            # Get the outward peak point of the triangle bump
            peak = self.peakpoint(p13, p23)
            # Recursively display four segments
            self.displaySegments(order - 1, p1, p13)
            self.displaySegments(order - 1, p13, peak)
            self.displaySegments(order - 1, peak, p23)
            self.displaySegments(order - 1, p23, p2)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags = "line")

    # Return the 1/3 or 2/3 point between two points
    def thirdpoint(self, p1, p2, n):
        p = 2 * [0]
        p[0] = p1[0] + n * (p2[0] - p1[0]) / 3
        p[1] = p1[1] + n * (p2[1] - p1[1]) / 3
        return p

 # 
    def peakpoint(self, p1, p2):
        p = 2 * [0]
        dx = p2[0] - p1[0]
        dy = p2[1] - p1[1]
        p[0] = p1[0] + dx / 2 + dy * math.sqrt(3) / 2
        p[1] = p1[1] + dy / 2 - dx * math.sqrt(3) / 2
        return p

KochSnowflake() # Create GUI