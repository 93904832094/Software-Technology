#===graph.py===
class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph:
            self.graph[vertex1] = [v for v in self.graph[vertex1] if v != vertex2]
        if not self.directed and vertex2 in self.graph:
            self.graph[vertex2] = [v for v in self.graph[vertex2] if v != vertex1]

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]
        for v in self.graph:
            self.graph[v] = [x for x in self.graph[v] if x != vertex]

    def print_graph(self):
        for vertex in self.graph:
            edges = self.graph[vertex]
            if self.weighted:
                edge_str = ', '.join(f"{e}(w={self.weights.get((vertex, e), '?')})" for e in edges)
            else:
                edge_str = ', '.join(edges)
            print(f"{vertex} -> [{edge_str}]")

    def bfs(self, start):
        visited = []
        queue = [start]
        seen = set([start])
        while queue:
            vertex = queue.pop(0)
            visited.append(vertex)
            for neighbour in self.graph[vertex]:
                if neighbour not in seen:
                    seen.add(neighbour)
                    queue.append(neighbour)
        return visited

    def dfs(self, start):
        visited = []
        stack = [start]
        seen = set()
        while stack:
            vertex = stack.pop()
            if vertex not in seen:
                seen.add(vertex)
                visited.append(vertex)
                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in seen:
                        stack.append(neighbour)
        return visited

    def has_undirected_cycle(self):
        visited = set()

        def dfs_cycle(current, parent):
            visited.add(current)
            for neighbour in self.graph[current]:
                if neighbour not in visited:
                    if dfs_cycle(neighbour, current):
                        return True
                elif neighbour != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_cycle(vertex, None):
                    return True
        return False