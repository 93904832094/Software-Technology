from graph import Graph

# Basic undirected graph tests
print("=== Undirected Graph ===")
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("After adding vertices A, B, C, D and edges:")
g.print_graph()

print()

# Directed graph tests
print("=== Directed Graph ===")
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("After adding vertices A, B, C, D and edges:")
g.print_graph()

print()

# Weighted graph tests
print("=== Weighted Directed Graph ===")
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)
g.add_edge('C', 'D', 20)
print("After adding vertices A, B, C, D and weighted edges:")
g.print_graph()

print()

# Removal tests
print("=== Removal Test ===")
removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')
removal_test.add_vertex('D')
removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')
removal_test.add_edge('C', 'D')
print("Initial graph:")
removal_test.print_graph()

removal_test.remove_edge('A', 'B')
print("\nAfter removing edge A-B:")
removal_test.print_graph()

removal_test.remove_vertex('C')
print("\nAfter removing vertex C:")
removal_test.print_graph()